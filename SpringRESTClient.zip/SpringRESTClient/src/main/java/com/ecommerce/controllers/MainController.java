package com.ecommerce.controllers;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ecommerce.beans.Quote;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import com.ecommerce.beans.Quote;

@Controller
public class MainController {
	@RequestMapping("/")
	@ResponseBody
	public String index() {
	    RestTemplate restTemplate = new RestTemplate();
	    // Make a request to get the plain text response
	    ResponseEntity<String> responseEntity = restTemplate.getForEntity("https://type.fit/api/quotes", String.class);
	    // Get the response body as a String
	    String responseBody = responseEntity.getBody();
	    // Convert the plain text response to a List of Quote objects
	    List<Quote> quotes = convertStringToQuoteList(responseBody);

	    // Handle the case where quotes is null or empty
	    if (quotes == null || quotes.isEmpty()) {
	        return "No quotes available";
	    }
	    // For simplicity, just return the first quote's toString representation
	    return quotes.get(0).toString();
	}

	
	private List<Quote> convertStringToQuoteList(String jsonString){
	    try {
	        // Use Jackson ObjectMapper to convert JSON string to a List of Quote objects
	        ObjectMapper objectMapper = new ObjectMapper();
	        TypeReference<List<Quote>> typeReference = new TypeReference<List<Quote>>() {};
	        return objectMapper.readValue(jsonString, typeReference);
	    } catch (Exception e) {
	        // Handle any exceptions that might occur during the conversion
	        e.printStackTrace();
	        return null; // Or throw an exception based on your error handling strategy
	    }
	}
}