package com.test.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestAptTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestAptTestApplication.class, args);
	System.out.println("Nani");
	}

}
