package com.ecommerce.controllers;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileInputStream;

@Controller
public class MainController {

    @RequestMapping(value = "/")
    public String index() {
        return "index.html";
    }

    @PostMapping("/upload")
    @ResponseBody
    public String fileUpload(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return "File is empty";
        }

        try {
            // Assuming you want to store files in the "uploads" directory within your project
            File uploadDir = new File("uploads");
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            File convertedFile = new File(uploadDir, file.getOriginalFilename());
            try (FileOutputStream fout = new FileOutputStream(convertedFile)) {
                fout.write(file.getBytes());
            }

            return "File uploaded successfully";
        } catch (IOException e) {
            return "Error uploading file: " + e.getMessage();
        }
    }

    @RequestMapping(value = "/uploaded/{fileName:.+}", method = RequestMethod.GET)
    public ResponseEntity<Object> downloadUploadedFile(@PathVariable String fileName) throws IOException {
        File file = new File("/var/tmp/" + fileName);

        if (!file.exists()) {
            return ResponseEntity.notFound().build();
        }
        
        InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", String.format("attachment; filename=\"%s\"", file.getName()));
        headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
        headers.add("Pragma", "no-cache");
        headers.add("Expires", "0");
        return ResponseEntity.ok().headers(headers).contentLength(file.length())
                .contentType(MediaType.parseMediaType("application/octet-stream")).body(resource);
    }
}
