
public class ExponentialSearch {

}
